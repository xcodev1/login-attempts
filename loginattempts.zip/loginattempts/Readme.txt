How to run How to limit login attempt Using PHP and MySQL script 

1.Download the zip file

2.Extract the file and copy loginattempts folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5.Create a database with name loginattemp

6.Import loginattemp.sql file(Available inside the zip package)

7.Run the script http://localhost/hmms